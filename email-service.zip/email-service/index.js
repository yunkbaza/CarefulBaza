const nodemailer = require('nodemailer');

exports.handler = async (event) => {
  try {
    // O Lambda recebe os dados em formato de string, precisamos de converter para JSON
    const body = JSON.parse(event.body);
    const { to, subject, html } = body;

    // Configura a ligação ao Gmail usando as variáveis da AWS
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    // Executa o envio
    await transporter.sendMail({
      from: '"Careful Baza Labs" <carefulbaza@gmail.com>',
      to: to,
      subject: subject,
      html: html
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ message: "E-mail enviado com sucesso pelo Lambda!" }),
    };
  } catch (error) {
    console.error("Erro interno no Lambda:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Falha ao enviar e-mail." }),
    };
  }
};